# How it works :
|**!<>!**       |**Finished**                    |**Name**          |**Version**                               |**Displayed**|**Date**  |**Creator(s)**|
|:--------------|:-------------------------------|:-----------------|:-----------------------------------------|:------------|:--------:|:-------------|
|Warn with **@**|yes<br/>no<br/>could change : cc|Name of your model|vX.Y<br/>X : big change<br/>Y small change|On site?     | DD/MM/YY |Creators :)   |

> Last update : 6th January 2020

-------------------------------------------------

## A
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |acacia_trapdoor       |           |no           |          |Progical      |
|        |yes         |acacia_door           |v1         |no           |07/02/19  |Juknum        |
|**@**   |yes         |acacia_boat           |v1.1       |no           |28/10/19  |Juknum        |
|        |yes         |armor_stand           |v1         |no           |07/02/19  |Juknum        |

## B
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|**@**   |yes         |birch_boat            |v1.1       |yes          | 28/10/19 |Juknum        |
|        |yes         |birch_trapdoor        |           |yes          |          |Progical      |
|        |yes         |birch_door           |v1         |no           |07/02/19  |Juknum        |
|        |yes         |bow					 |           |yes          |          |Howler        |
|        |yes         |bow_pulling_0		 |           |not needed   |          |Howler        |
|        |yes         |bow_pulling_1		 | 	         |not needed   |          |Howler        |
|        |yes         |bow_pulling_2		 | 			 |not needed   |          |Howler        |

## C
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |campfire              |v1         |no           | 31/01/20 |Juknum        |
|        |yes         |carrot_on_a_stick     |v1         |no           | 01/02/20 |Juknum        |
|        |yes         |cauldron				 |           |yes          | 		  |Juknum 		 |
|        |yes         |chest_minecart		 |           |no           | 28/10/19 |Juknum 		 |
|        |yes         |command_block_minecart|           |no           | 28/10/19 |Juknum 		 |
|        |yes         |composter			 |           |no           | 		  |Juknum 		 |

## D
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |dark_oak_trapdoor     |		 	 |no  		   |		  |Progical      |
|        |yes         |dark_oak_door         |v1         |no           |07/02/19  |Juknum        |
|**@**   |yes         |dark_oak_boat		 |v1.1       |no  		   | 28/08/19 |Juknum        |
|        |yes         |door_display          |v1         |no           |07/02/19  |Juknum        |
|        |yes         |diamond_axe			 |		 	 |yes 		   | 		  |Howler        |
|        |yes         |diamond_hoe			 |		 	 |yes 		   | 		  |Howler        |
|        |yes         |diamond_pickaxe		 | 		 	 |yes 		   | 		  |Howler        |
|        |yes         |diamond_shovel		 |		 	 |yes 		   | 		  |Howler        |
|        |yes         |diamond_sword		 | 		  	 |yes 		   | 		  |Howler        |
|        |yes         |dragon_breath		 |		 	 |yes 		   | 		  |Juknum        |

## E
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |experience_bottle 	 |		 	 |yes          |		  |Juknum        |

## F
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |farmland				 |		 	 |yes		   | 30/08/19 |Juknum	 	 |
|        |yes         |firework_rocket       |v1         |yes          | 31/01/20 |Juknum        |
|        |yes         |fishing_rod			 |		 	 |yes		   |		  |Howler	 	 |
|        |yes         |fishing_rod_cast		 |		 	 |yes		   |		  |Howler	 	 |
|        |yes         |flower_pot			 |		 	 |yes		   | 28/10/19 |Juknum	 	 |
|        |yes         |furnace_minecart		 |		 	 |yes		   | 28/10/19 |Juknum		 |

## G
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |glass_bottle			 |		 	 |yes	 	   |		  |Juknum 		 |
|        |yes         |golden_axe			 |		 	 |yes 		   | 		  |Howler		 |
|        |yes         |golden_hoe			 |		 	 |yes 		   |		  |Howler		 |
|        |yes         |golden_pickaxe		 |		 	 |yes 		   |		  |Howler		 |
|        |yes         |golden_shovel		 |		 	 |yes 		   |		  |Howler		 |
|        |yes         |golden_sword			 |		 	 |yes 		   |		  |Howler		 |

## H
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |honey_bottle			 |		 	 |		 	   |		  |Juknum		 |
|        |yes         |hopper				 |		 	 |		 	   | 26/08/19 |Juknum		 |
|        |yes         |hopper_minecart		 |		 	 |		 	   | 28/10/19 |Juknum		 |

## I
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |iron_axe				 |           |yes          |		  |Howler        |
|        |yes         |iron_hoe				 |           |yes          |		  |Howler        |
|        |yes         |iron_pickaxe			 |           |yes          |		  |Howler        |
|        |yes         |iron_shovel			 |		 	 |yes 		   |		  |Howler        |
|        |yes         |iron_sword			 |		 	 |yes	 	   | 		  |Howler        |
|        |yes         |iron_trapdoor		 |		 	 |no		   |	      |Progical      |
|        |yes         |iron_door             |v1         |no           |07/02/19  |Juknum        |

## J
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |jungle_trapdoor		 |		 	 |no		   |          |Progical	     |
|        |yes         |jungle_door           |v1         |no           |07/02/19  |Juknum        |
|**@**   |yes         |jungle_boat			 |v1.1       |no		   | 28/10/19 |Juknum	     |				

## L
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |lantern				 |		 	 |no		   |		  |Juknum		 |
|        |yes         |lingering_potion		 |		 	 |no		   |		  |Juknum		 |

## M
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |minecart				 |		 	 |no		   | 28/10/19 |Juknum        |

## O
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |oak_trapdoor			 |		 	 |not needed   |	      |Progical      |
|        |yes         |oak_door              |v1         |no           |07/02/19  |Juknum        |
|**@**   |yes         |oak_boat				 |v1.1       |no		   | 28/10/19 |Juknum	     |

## P
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |piston				 |		     |not needed   | 26/08/19 |Juknum		 |
|        |yes         |potion				 |        	 |yes          |		  |Juknum	     |

## S
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |shears				 |		 	|yes          |			 |Howler         |
|        |yes         |shield				 |		 	|no           |			 |?              |
|        |yes         |shield_blocking   	 |		 	|no           |			 |?              |
|        |yes         |shulker_shell    	 |		 	|no           |	31/01/20 |Juknum         |
|        |yes         |splash_potion		 |		 	|yes          |			 |Howler         |
|        |yes         |spruce_boat			 |v1.1      |yes          |	28/10/19 |Juknum	  	 |
|        |yes         |sticky_piston		 |		 	|not needed	  | 26/08/19 |Juknum	     |
|        |yes         |stone_axe			 |		 	|yes          |			 |Howler         |
|        |yes         |stone_hoe			 |		 	|yes          |			 |Howler         |
|        |yes         |stone_pickaxe		 |		 	|yes          |			 |Howler         |
|        |yes         |stone_shovel			 |		 	|yes          |			 |Howler         |
|        |yes         |stone_sword			 |		 	|yes          |			 |Howler         |
|        |yes         |stonecutter			 |		 	|yes          |			 |Juknum	 	 |

## T
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |tnt_minecart			 |           |no 		   | 28/08/19 |Juknum		 |

## W
|**!<>!**|**Finished**|**Name**              |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:---------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |wooden_axe			 |           |yes          |		 |Howler        |
|        |yes         |wooden_hoe			 |           |yes          |		 |Howler        |
|        |yes         |wooden_pickaxe		 |           |yes          |		 |Howler        |
|        |yes         |wooden_shovel		 |           |yes          |		 |Howler        |
|        |yes         |wooden_sword			 | 		     |yes		   |		 |Howler        |
