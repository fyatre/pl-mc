**[EN]**

# IMPORTANT INFORMATION
      
- Our website : https://sites.google.com/view/faithful-3d-addon
- Our Curse Forge : https://www.curseforge.com/minecraft/texture-packs/faithful-3d
- Faithful 3D is an addon for the Faithful 32x32 texture pack and requires it to work properly : https://faithful.team/
- You may use Faithful 3D for your own resource packs, but please credit it and do not distribute it on any other site.
- Only works on Minecraft Java Edition for 1.15.x (Previous versions may not be supported, you can download them on our Curse).
- You can join us on our discord server: https://discordapp.com/invite/GJzgeY7 

# CREATORS

- **Juknum:** *Twitter:* https://twitter.com/Juknum_
- **Progical**
- **Howler:** *Twitter:* https://twitter.com/UnlikeHowler

______________________________________________________________________________________________________________

**[FR]**

# INFORMATIONS IMPORTANTES 

- Notre site web (en anglais) : https://sites.google.com/view/faithful-3d-addon
- Notre Curse Forge : https://www.curseforge.com/minecraft/texture-packs/faithful-3d
- Le Faithful 3D est un addon du Faithful, il est donc requis pour fonctionner normalement : https://faithful.team/
- Vous pouvez utilisez le Faithful 3D pour vos propres ressources packs, cependant merci de le mentionner.
- Fonctionne seulement avec l'Edition Java pour la version 1.15.x (Les versions précédentes ne seront peut-êtres pas supportées, téléchargez les sur notre Curse).
- Vous pouvez nous rejoindre sur notre serveur discord : https://discordapp.com/invite/GJzgeY7

# CREATEURS

- **Juknum:** *Twitter:* https://twitter.com/Juknum_
- **Progical**
- **Howler:** *Twitter:* https://twitter.com/UnlikeHowler

______________________________________________________________________________________________________________
